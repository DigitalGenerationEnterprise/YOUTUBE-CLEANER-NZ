# Privacy summary

NZ YouTube Relevance Cleaner does not collect, transmit, sell, or share browsing data.

Processing occurs locally in the browser. The extension reads visible YouTube result text and the current YouTube search query solely to apply user-selected rules. Settings are saved with Chromium's extension storage. Browser-level sync, if enabled by the user, is controlled by the browser vendor.

The extension contains no analytics, telemetry, advertising, remote code, background service worker, or network-request code.
