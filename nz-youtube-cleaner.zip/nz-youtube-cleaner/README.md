# NZ YouTube Relevance Cleaner

An inspectable Manifest V3 Chromium extension that gives the user transparent controls over YouTube search and result pages.

It is a relevance tool, not a nationality or ethnicity filter. It only uses visible page text, URL search terms, and lists the user enters.

## What it does

- boosts results with configurable NZ/local text signals
- boosts and protects preferred channels
- hides manually blocked channels
- suppresses Shorts
- hides likely duplicates using normalized titles on the current page
- hides obvious clickbait using listed title rules
- can require an NZ signal when the user's own search has local intent
- labels each decision and shows a page summary

Preferred channels override block and quality rules. Every rule can be switched off.

## Install on current Chromium or Chrome on Kubuntu

1. Unzip this package somewhere permanent, for example `~/Applications/nz-youtube-cleaner`.
2. Open Chromium or Chrome.
3. Enter `chrome://extensions` in the address bar.
4. Turn on **Developer mode** at the top right.
5. Click **Load unpacked**.
6. Select the unzipped folder containing `manifest.json`.
7. Pin **NZ YouTube Relevance Cleaner** from the extensions menu.
8. Open YouTube and refresh any already-open YouTube tabs.

For Chromium, `chrome://extensions` is still the correct address. Keep the folder after installation. If you move or delete it, Chromium cannot load the extension.

## Settings

Click the extension icon for common toggles, then **Open all settings** for:

- preferred channels, one per line
- blocked channels, one per line
- NZ/local signals, one per line
- duplicate, clickbait, Shorts, local-intent and explanation controls

Settings use `chrome.storage.sync`. Depending on browser sign-in settings, Chromium may sync them through the browser vendor. The extension itself has no analytics, network calls, server, account, or browsing-history store.

## Transparent rules

Clickbait checks are deliberately narrow:

- mostly capital letters
- three or more repeated `!` or `?`
- three or more emoji/decorative symbols
- phrases: "you won't believe", "shocking", "must watch", "gone wrong", "what happens next", "they don't want you to know"

Duplicate detection strips punctuation and generic terms such as `official`, `video`, `HD`, `4K`, `lyrics`, `reupload`, `full`, and four-digit years. It compares results already visible on the current page. It does not fingerprint video files.

## Permissions and privacy

- `storage`: saves settings
- `https://www.youtube.com/*`: runs only on YouTube

There is no background service worker, remote code, telemetry, ad blocking, account access, or external request. Source is included and readable.

## Limitations

- YouTube changes its HTML frequently. Selectors may need maintenance.
- Text signals are relevance hints, not proof a video or creator is from New Zealand.
- Results loaded later are rechecked, but YouTube's virtual scrolling can still cause temporary ordering changes.
- Boosting uses CSS order where YouTube's layout permits it. On some shelves, the green label may appear without a full reorder.
- Clickbait and duplicate rules can produce false positives. Preferred channels and switches provide overrides.
- The extension does not inspect speech, images, geolocation, uploader identity, nationality, ethnicity, or private account data.
- It is unpacked software for private use. It is not published to the Chrome Web Store and will not auto-update.

## Inspect and test

```bash
node tests/rules.test.js
python3 tests/static_check.py
```

Review `manifest.json`, `src/rules.js`, and `src/content.js` to inspect all behavior.

## Remove

Open `chrome://extensions`, find the extension, and click **Remove**. Delete the extracted folder if no longer needed.
