(() => {
  const R = globalThis.NZYTRules;
  if (!R) return;
  const SELECTORS = [
    "ytd-video-renderer", "ytd-grid-video-renderer", "ytd-rich-item-renderer",
    "ytd-compact-video-renderer", "ytd-reel-item-renderer"
  ].join(",");
  let settings = R.DEFAULTS, timer;
  const getQuery = () => new URL(location.href).searchParams.get("search_query") || "";
  const text = (root, selectors) => {
    for (const s of selectors) { const el = root.querySelector(s); if (el?.textContent?.trim()) return el.textContent.trim(); }
    return "";
  };
  const readItem = el => ({
    title: text(el, ["#video-title", "a#video-title-link", "h3 a", "#video-title-link"]),
    channel: text(el, ["ytd-channel-name", "#channel-name", ".ytd-channel-name", "#text.ytd-channel-name"]),
    metadata: text(el, ["#metadata-line", "#metadata"]),
    isShort: el.matches("ytd-reel-item-renderer") || !!el.closest("ytd-reel-shelf-renderer") || /\/shorts\//.test(el.querySelector("a[href]")?.href || "")
  });
  const clear = el => {
    el.classList.remove("nzyt-hidden", "nzyt-boosted");
    el.style.removeProperty("order");
    el.querySelector(":scope > .nzyt-reason")?.remove();
  };
  function apply() {
    document.querySelectorAll(SELECTORS).forEach(clear);
    document.querySelectorAll(".nzyt-summary").forEach(x => x.remove());
    if (!settings.enabled) return;
    const seen = new Set(), items = [...document.querySelectorAll(SELECTORS)];
    let hidden = 0, boosted = 0;
    items.forEach((el, index) => {
      const verdict = R.evaluate(readItem(el), settings, seen, getQuery());
      if (verdict.hide) { el.classList.add("nzyt-hidden"); hidden++; }
      if (verdict.boost && !verdict.hide) { el.classList.add("nzyt-boosted"); el.style.order = String(-1000 + index); boosted++; }
      if (settings.showReasons && verdict.reasons.length) {
        const badge = document.createElement("div");
        badge.className = "nzyt-reason";
        badge.textContent = `NZ Cleaner: ${verdict.reasons.join(" · ")}`;
        badge.title = "This label explains the local rule used. Change rules in extension settings.";
        el.prepend(badge);
      }
    });
    if (hidden || boosted) {
      const anchor = document.querySelector("ytd-search, ytd-browse #contents, #primary");
      if (anchor) {
        const summary = document.createElement("div");
        summary.className = "nzyt-summary";
        summary.textContent = `NZ Cleaner: ${boosted} boosted · ${hidden} hidden. Rules run only in this tab.`;
        anchor.prepend(summary);
      }
    }
  }
  const schedule = () => { clearTimeout(timer); timer = setTimeout(apply, 180); };
  chrome.storage.sync.get(R.DEFAULTS, value => { settings = value; apply(); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    for (const [k, v] of Object.entries(changes)) settings[k] = v.newValue;
    schedule();
  });
  new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true });
  addEventListener("yt-navigate-finish", schedule);
})();
