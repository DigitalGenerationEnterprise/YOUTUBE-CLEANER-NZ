(() => {
  const DEFAULTS = {
    enabled: true,
    boostNZ: true,
    hideBlocked: true,
    suppressShorts: true,
    filterDuplicates: true,
    filterClickbait: true,
    requireNZForLocalIntent: false,
    showReasons: true,
    nzTerms: ["new zealand", "aotearoa", "nz", "kiwi", "auckland", "wellington", "christchurch", "hamilton", "tauranga", "dunedin", "queenstown", "rotorua", "northland", "waikato", "canterbury", "otago"],
    preferredChannels: [],
    blockedChannels: []
  };
  const CLICKBAIT = [
    { id: "caps", label: "mostly capital letters", test: s => s.length >= 12 && (s.match(/[A-Z]/g) || []).length / Math.max(1, (s.match(/[A-Za-z]/g) || []).length) > 0.72 },
    { id: "punctuation", label: "excess punctuation", test: s => /([!?])\1{2,}/.test(s) },
    { id: "bait-phrase", label: "common bait phrase", test: s => /\b(you won'?t believe|shocking|must watch|gone wrong|what happens next|they don'?t want you to know)\b/i.test(s) },
    { id: "emoji", label: "heavy emoji/decorative symbols", test: s => ((s.match(/[\u{1F300}-\u{1FAFF}]/gu) || []).length >= 3) }
  ];
  const clean = s => String(s || "").toLowerCase().replace(/&amp;/g, "and").replace(/[^a-z0-9]+/g, " ").trim();
  const channelMatches = (channel, list) => list.some(x => clean(channel) === clean(x) || clean(channel).includes(clean(x)));
  const hasNZSignal = (text, settings) => settings.nzTerms.some(t => {
    const term = clean(t), hay = ` ${clean(text)} `;
    return term.length <= 2 ? hay.includes(` ${term} `) : hay.includes(term);
  });
  const normalizedTitle = title => clean(title)
    .replace(/\b(official|video|hd|4k|lyrics?|reupload|re upload|full)\b/g, "")
    .replace(/\b\d{4}\b/g, "").replace(/\s+/g, " ").trim();
  const localIntent = (query, settings) => hasNZSignal(query, settings);
  function evaluate(item, settings, seen = new Set(), query = "") {
    const s = Object.assign({}, DEFAULTS, settings || {});
    const title = item.title || "", channel = item.channel || "";
    const preferred = channelMatches(channel, s.preferredChannels);
    const blocked = channelMatches(channel, s.blockedChannels);
    const nz = hasNZSignal(`${title} ${channel} ${item.metadata || ""}`, s);
    const reasons = [];
    let hide = false, boost = false;
    if (s.hideBlocked && blocked && !preferred) { hide = true; reasons.push("blocked channel"); }
    if (s.suppressShorts && item.isShort && !preferred) { hide = true; reasons.push("Short"); }
    const key = normalizedTitle(title);
    if (s.filterDuplicates && key.length >= 16 && seen.has(key) && !preferred) { hide = true; reasons.push("likely duplicate title"); }
    if (key) seen.add(key);
    if (s.filterClickbait && !preferred) {
      const hit = CLICKBAIT.find(r => r.test(title));
      if (hit) { hide = true; reasons.push(`clickbait: ${hit.label}`); }
    }
    if (s.requireNZForLocalIntent && localIntent(query, s) && !nz && !preferred) { hide = true; reasons.push("no NZ signal for local search"); }
    if ((s.boostNZ && nz) || preferred) { boost = true; reasons.push(preferred ? "preferred channel" : "NZ signal"); }
    return { hide, boost, nz, preferred, blocked, reasons, key };
  }
  const API = { DEFAULTS, CLICKBAIT, clean, channelMatches, hasNZSignal, normalizedTitle, localIntent, evaluate };
  globalThis.NZYTRules = API;
  if (typeof module !== "undefined") module.exports = API;
})();
