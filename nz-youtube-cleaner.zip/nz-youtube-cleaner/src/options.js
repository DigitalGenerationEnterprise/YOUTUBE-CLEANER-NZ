(() => {
  const D = NZYTRules.DEFAULTS;
  const bools = ["enabled","boostNZ","suppressShorts","showReasons","filterDuplicates","filterClickbait","requireNZForLocalIntent","hideBlocked"];
  const lists = ["preferredChannels","blockedChannels","nzTerms"];
  const parse = value => [...new Set(value.split(/\n/).map(x => x.trim()).filter(Boolean))];
  const render = data => { bools.forEach(k => document.getElementById(k).checked = !!data[k]); lists.forEach(k => document.getElementById(k).value = (data[k] || []).join("\n")); };
  const flash = text => { const s = document.getElementById("status"); s.textContent = text; setTimeout(() => s.textContent = "", 1800); };
  chrome.storage.sync.get(D, render);
  document.getElementById("save").addEventListener("click", () => {
    const out = {}; bools.forEach(k => out[k] = document.getElementById(k).checked); lists.forEach(k => out[k] = parse(document.getElementById(k).value));
    chrome.storage.sync.set(out, () => flash("Saved"));
  });
  document.getElementById("reset").addEventListener("click", () => chrome.storage.sync.set(D, () => { render(D); flash("Defaults restored"); }));
})();
