import json, pathlib
root=pathlib.Path(__file__).parents[1]
m=json.loads((root/'manifest.json').read_text())
assert m['manifest_version']==3
assert m['permissions']==['storage']
assert m['host_permissions']==['https://www.youtube.com/*']
paths=[root/'manifest.json',*list((root/'src').glob('*'))]
alltext='\n'.join(p.read_text(errors='ignore') for p in paths if p.is_file())
for bad in ['fetch(', 'XMLHttpRequest', 'webRequest', '<all_urls>', '"tabs"', '"history"']:
    assert bad not in alltext, bad
for f in ['src/rules.js','src/content.js','src/options.html','src/options.js','README.md','PRIVACY.md']:
    assert (root/f).exists(), f
print('static_check.py: manifest and privacy checks passed')
